import { FilterIdPipe } from './filter-id.pipe';

describe('FilterIdPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterIdPipe();
    expect(pipe).toBeTruthy();
  });
});
