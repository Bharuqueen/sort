"use strict";
exports.__esModule = true;
var Mobile_1 = require("./Mobile");
var BasicPhone_1 = require("./BasicPhone");
var SmartPhone_1 = require("./SmartPhone");
var a = [{
        name: "ndn",
        cost: 768,
        id: 879
    },
    {
        name: "1ndn",
        cost: 728,
        id: 890,
        type: "dd"
    },
    {
        name: "2ndn",
        cost: 728,
        id: 890,
        type: "dd1"
    }];
var mobile = new Mobile_1.Mobile(a[0].name, a[0].cost, a[0].id);
mobile.printMobile();
var basic = new BasicPhone_1.BasicPhone(a[1].name, a[1].cost, a[1].id, a[1].type);
basic.printMobile();
var smart = new SmartPhone_1.SmartPhone(a[2].name, a[2].cost, a[2].id, a[2].type);
smart.printMobile();
